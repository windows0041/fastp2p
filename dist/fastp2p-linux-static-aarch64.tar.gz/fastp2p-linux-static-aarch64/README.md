# fastp2p C 客户端

本仓库包含客户端、C SDK 和 Android 应用。网关服务和 Web 控制台在独立的 [fastp2p-gateway 仓库](https://github.com/windows0041/fastp2p-gateway)。客户端安装包见 [GitHub Releases](https://github.com/windows0041/fastp2p/releases)。

C11 核心提供 WSS 协调、QUIC、TCP 打洞、中继回退、TCP/UDP 转发和 SOCKS5。隧道帧用 AES-256-GCM 保护：发起端生成 256 位会话密钥并经网关的 TLS 通道送达对端，两个方向各自派生密钥，接收端维护重放窗口。公开接口位于 `include/fastp2p.h`，符号前缀 `fastp2p_`，ABI 1。调用者独占客户端对象并驱动 `fastp2p_client_step`；回调属于驱动线程，销毁前停止调用。

QUIC 接收采用有界环形缓冲，帧编码复用发送队列。[缓冲优化基准与验证](docs/performance-20261112.md) 包含可选基准的构建方法和适用范围。

TCP/UDP 分开检测映射并选择重试策略。新版 TCP 打洞支持双方同时连接、同源端口重试和监听回退；网关控制台分别显示两种协议的结果。[TCP 打洞与检测说明](docs/tcp-punch.md) 包含配置、兼容方式和隔离 NAT 测试方法。

UDP 和 TCP 的 NAT 等级分别使用映射和入站过滤的观测。默认通过 `stun.fastp2p.top:3478` 做 UDP STUN 过滤探测，通过 `stun.fastp2p.top:3479` 做 TCP 回连探测。UDP 探测把实际回包的源地址和端口与请求目标比较。TCP 探测需要同地址换端口和换地址两项结果。

过滤证据不足时，客户端会在 30 秒后重测。测出等级后每 10 分钟更新，短暂超时会保留最近确认的等级，满 20 分钟未重新确认会回到过滤待判定。可通过 `network.UDPSTUNServers` 和 `network.TCPNatProbe` 指定探测服务。自建 UDP 服务需支持 CHANGE-REQUEST。 [NAT 穿越说明](NAT-TRAVERSAL-ZH.md) · [自建探测服务](scripts/stun/README.md)

## 安装与运行

```sh
fastp2p run
fastp2p stop
fastp2p --version
fastp2p --licenses
```

安装 Token 为 16 位数字，网关地址、端口和公开 CA 已预置于专用客户端包。安装先完成 TLS 主机名校验及网关认证，成功后原子保存配置。错误凭据不会替换旧配置。支持 `--token`、`FASTP2P_INSTALL_TOKEN`、`--node`、`--config`、`--no-service`。

在网关控制台选择 Linux 并复制安装命令。脚本会识别 CPU，从网关通过 HTTPS 下载程序，并校验长度、SHA-256 和版本。下载程序需要 curl 或支持 TLS 的 GNU wget。程序安装到 `/usr/local/fastp2p/fastp2p`。各 Linux 发行版统一使用 `/etc/fastp2p/config.conf`，日志写入 `/tmp/fastp2p/fastp2p.log`。手动下载脚本时请保留文件名中的 Token。

脚本先在私有临时目录验证接入和合并配置，通过后才停止旧服务。安装后的服务默认以 root 运行，配置及包含凭据的目录由 root 私有。安装器验证监听端口、网关认证和服务运行状态，失败时恢复旧文件、目录权限和开机启动状态。在旧版安装上重新运行新版安装命令即可迁移服务权限并保留节点身份。若旧网关仍在共享客户端的数据目录，请先迁移网关。

安装成功后清理安装器管理的旧程序：Linux 删除历次 `.backups` 中的程序副本和旧路径的可执行文件，保留配置、证书和诊断日志；失败时先恢复旧程序，保留故障备份。客户端 2.0.5 起，Linux/macOS 远程升级在新程序认证上线并稳定运行 5 秒后删除 `.old`；Windows 升级辅助程序在新服务启动成功后清理旧 EXE，运行中的辅助 EXE 由新客户端在文件释放后清理。Windows 服务安装还会清理旧用户目录中的程序，保留该目录的配置。清理只匹配已知程序文件，跳过仍在工作的下载进程及目录、符号链接，不扫描下载目录中的用户安装包。Android 的旧应用由系统替换，安装成功回调清理缓存 APK。

安装脚本根据系统选择 systemd、procd 或 OpenRC。OpenWrt 和 ImmortalWrt 由 procd 保活，安装阶段使用的 `fastp2p-service` 脚本会在安装完成后移除。当前官方 Release 提供 x86_64、aarch64、armv7（硬浮点）、riscv64 和 mips64el（64 位小端用户空间）。安装脚本以网关提供的包为准，缺包时会列出可用架构并退出，旧服务保持运行。容器可直接运行对应架构的原始可执行文件。

在网关控制台点击「下载 Linux 通用安装脚本」。保留下载文件名，将下面引号内的示例替换为实际文件名执行；架构和 Token 会自动读取，无需额外输入。脚本固定下载时各架构的最新版；若旧包已清理，请重新下载脚本：

```sh
sudo sh './fastp2p-<下载文件名中的16位数字>'
```

Debian/Ubuntu/CentOS 等 systemd 系统查看服务和日志：

```sh
sudo systemctl status fastp2p-client --no-pager
sudo journalctl -u fastp2p-client -n 50 --no-pager
```

Alpine/OpenRC 用 `rc-service fastp2p status`，OpenWrt 用 `/etc/init.d/fastp2p status`。安装完成后程序在后台运行，不需要保持安装终端在线。

在 Linux 和 macOS 用 root 运行 `/usr/local/fastp2p/fastp2p stop` 可停止服务，运行 `/usr/local/fastp2p/fastp2p uninstall` 可卸载。加 `--keep-config` 可保留当前布局中的配置和节点身份。

macOS 在网关控制台的「安装客户端 → Mac」下载通用安装脚本。保留文件名，在终端执行 `sh ./fastp2p-macos-<16位数字>.sh` 并按提示输入管理员密码。脚本支持 macOS 13 及以上，自动下载 Apple Silicon 或 Intel 版本。程序、配置和日志与 Linux 使用相同路径，LaunchDaemon 随系统开机启动。

Windows 双击带 Token 文件名的 EXE，经 UAC 授权后安装到 `%ProgramFiles%\fastp2p`。服务配置使用机器级 DPAPI 加密，位于 `%ProgramData%\fastp2p\config.conf`，运行和安装日志位于 `%SystemRoot%\Temp\fastp2p\fastp2p.log`。高级 CLI 的当前用户配置在 `%LOCALAPPDATA%\fastp2p\config.conf`，使用当前用户 DPAPI。

Android 由系统安装 APK。接入密钥和客户端配置加密存放在应用私有目录的 `files/fastp2p/config.conf`，运行日志位于 `cache/fastp2p/fastp2p.log`。

从旧目录切换到这套布局时，请先用旧版卸载客户端，再从网关安装新版并重新接入。 旧版 macOS 使用登录启动项，先用 `launchctl bootout "gui/$(id -u)/top.fastp2p"` 停止服务，再移除 `~/Library/LaunchAgents/top.fastp2p.plist`。

Windows 开机服务和 `run --background` 不创建终端窗口；后台日志写入配置文件同目录的 `fastp2p.conf.log`。手动从终端运行前台命令时连接现有终端，管道和文件重定向继续可用。只有双击安装并完成 UAC 授权后，才创建安装进度终端和结果提示。服务崩溃或启动时 DNS/网络暂不可用导致退出时，Windows 服务管理器会按恢复策略重启客户端。

高级调试使用 `--config FILE`，参考 `config.example.json`、`config.socks5.example.json`。重复安装保留原有转发和 SOCKS5 规则；Web 新增规则保存在网关数据库，节点重连后恢复。

局域网设备可以使用入口节点的转发端口。编辑网关转发规则，把「监听地址」设置为入口节点的局域网 IP，留空时默认为 `127.0.0.1`。例如，入口监听 `192.168.50.1:2222`，出口选择 `newcounas`，目标可填写其所在局域网内的 `192.168.15.1:22`。同一局域网内的电脑连接入口即可使用目标服务。目标地址由出口节点访问，入口的访问范围由入口节点防火墙控制。

### Linux SD-WAN

SD-WAN 使用 Linux TUN 接口 `fastp2p0`，在 FastP2P 的 QUIC 隧道里传输 IPv4。两端有到网关及对端的 IPv6 路径即可建立 IPv4 网络。默认虚拟网段为 `10.3.2.0/24`，每个节点手动分配一个唯一虚拟地址。两端使用同一 FastP2P 账号下的节点名，并在各自客户端配置中列出对端。

**依赖**

- Linux 内核 TUN 驱动和可打开的 `/dev/net/tun`。容器或受限 VPS 需要宿主机提供该设备并允许 `CAP_NET_ADMIN`。
- `iproute2`（`ip` 命令）。Debian 和 Ubuntu 可用 `apt install iproute2` 安装，OpenWrt 可安装 `ip-full` 和 `kmod-tun`。
- 创建 TUN 和安装路由需要 `CAP_NET_ADMIN`。安装后的 Linux 服务以 root 运行。在容器里仍需由宿主机授予该能力。

使用包含 SD-WAN 的 Linux 安装包时，在安装脚本的执行命令中启用检查。把 `YOUR_TOKEN` 换成控制台提供的接入 Token。

```sh
curl -fsSL https://fastp2p.top:10008/linux/install | sudo env FASTP2P_SDWAN=1 sh -s -- --token YOUR_TOKEN
```

脚本会检查依赖和 TUN 创建权限，缺失时提示并退出。现有安装可用 `sudo fastp2p --check-sdwan` 手动检查。普通安装无需这些依赖。

**两台 VPS**

在各自 `config.conf` 根对象加入 `sdwan` 字段，保留已有 `network` 等配置。可运行 `fastp2p --service-profile` 查看托管配置路径。以下两个片段分别定义 A、B 的虚拟地址，并互相导出一个 IPv4 子网。仅需虚拟 IP 互通时可以省略 `LocalRoutes` 和 `Routes`。

VPS A 的配置片段

```json
"sdwan": {
  "Address": "10.3.2.1",
  "LocalRoutes": ["192.168.50.0/24"],
  "Peers": [{"Node": "sdwan-vps-b", "Address": "10.3.2.2", "Routes": ["192.168.15.0/24"]}]
}
```

VPS B 的配置片段

```json
"sdwan": {
  "Address": "10.3.2.2",
  "LocalRoutes": ["192.168.15.0/24"],
  "Peers": [{"Node": "sdwan-vps-a", "Address": "10.3.2.1", "Routes": ["192.168.50.0/24"]}]
}
```

把 `Node` 换成控制台显示的实际节点名，修改后运行 `sudo systemctl restart fastp2p-client`。从 A 测试 `ping -4 10.3.2.2`，并用 `ip -4 route show dev fastp2p0` 查看已添加的路由。两端也可用同一个 `Subnet` 字段覆盖默认虚拟网段。

**子网路由**

`LocalRoutes` 声明本机负责转发的子网，必须从本机可达。`Peers[].Routes` 把对端负责的子网安装为经 TUN 到达的路由。按最长前缀选路。转发到子网里的其他设备时，需要在对应 VPS 开启 `net.ipv4.ip_forward=1`，允许防火墙在本地接口与 `fastp2p0` 之间转发，并在目标网段的网关上设置回程路由。子网互访时，两侧都需有回程路由。FastP2P 保留原始 IPv4 源地址，网段中其他设备可通过网关回程。

TUN 支持单播 IPv4，只安装配置中的对端地址及子网路由。已存在的同前缀路由会使启动报错，停止客户端会释放 TUN 及其路由。IPv6 直连需让对端访问节点的 UDP 业务端口；若使用中继，中继节点也须运行支持 SD-WAN 的客户端。

### Windows SD-WAN

Windows x86_64 客户端随单文件 EXE 打包官方签名的 Wintun。安装为 Windows 服务后，可在网关控制台将设备加入 SD-WAN 并分配虚拟 IPv4。服务为对端虚拟地址和共享子网安装路由，停止组网或服务时清理对应的网卡和路由。在管理员 PowerShell 中可检查依赖和已配置的虚拟网卡。

```powershell
& "$env:ProgramFiles\fastp2p\fastp2p.exe" --check-sdwan
Get-NetIPAddress -InterfaceAlias fastp2p0 -AddressFamily IPv4
Get-NetRoute -InterfaceAlias fastp2p0 -AddressFamily IPv4
```

从 Windows 分享本机子网时，还需要在相关 LAN 接口启用 IPv4 转发，允许防火墙转发，并在子网网关配置回程路由。

### Android SD-WAN

从 FastP2P 通知打开「SD-WAN」，粘贴 `sdwan` 的 JSON 对象。保存配置时应用会先尝试通过 `su` 建立 TUN。系统缺少 Root 授权或无法建立 Root TUN 时，在通知中选择「授权 VPN」，按 Android 提示确认即可。本机可访问配置的虚拟地址和对端子网。在 Android 上向其他节点发布手机所在子网需要 Root，并需另外配置 IPv4 转发、防火墙和回程路由。

SOCKS5 的 CONNECT 和 UDP ASSOCIATE 支持 IPv4、IPv6 以及由出口节点解析的域名。双栈节点优先直连 IPv6，失败时会重新协商 IPv4 直连。

### 业务端口

客户端在 `1024–9999` 中按设备身份选择可用端口，TCP 和 UDP 共用端口号，IPv4 和 IPv6 也用同一个端口。已安装的客户端首次上线后将它保存为 `network.PublicIPPort`。如需指定端口，可以在配置中设置 `PublicIPPort`，也可以用 `--publicipport PORT` 启动。

如果指定的 TCP 端口已占用或被系统保留，客户端会尝试在 `1024–9999` 中选择一个 TCP 和 UDP 都可用的端口，并把实际端口上报网关。下次启动仍优先尝试原配置端口。如果指定端口只能绑定 TCP，详情显示 TCP，QUIC 通过打洞连接。

在网关「设备详情」查看业务端口及协议，在设备防火墙放行实际端口。可在路由器上把同号的公网 TCP 和 UDP 端口转发到设备，或设置 `network.AutoPortMapping` 为 `true`，让客户端在 IPv4 默认路由器上通过 UPnP IGD 或 NAT-PMP 申请并续租实际监听端口。自动映射默认关闭。仅发起方有可用 UDP 映射时，新客户端也可以让应答方反向发起 QUIC 连接。直连失败会回到打洞流程。如果外层还有 NAT，例如运营商 CGNAT，仍需由外层网络决定公网可达性。

路由器 WAN 地址与客户端探测到的公网 IPv4 一致时，设备详情的「公网 IPv4 映射」会显示当前租约的外部 TCP、UDP 端口。映射状态会随租约更新，入站可达性还取决于防火墙。

找不到 UPnP IGD 且没有活跃映射时，SSDP 每五分钟重新查找一次。退出时，客户端会在两秒的路由器通信预算内尝试删除租约。路由器未响应时，租约可在到期后自行清除。

设置 `FASTP2P_FORCE_RELAY=1` 可跳过打洞直接请求中继，用于验证中继链路；它只影响带该变量启动的进程，不写入配置。

Linux 和 macOS 的在线升级先在 `/tmp` 下载并校验，再把新程序放到安装目录原子替换。支持交换或硬链接的文件系统只需要为新程序留出空间。两者都不可用时，升级器会先准备旧程序的回滚副本，再替换。准备或替换失败时，运行中的客户端会把原因回传到支持升级状态的网关。

## 构建与 SDK

在 Linux 或 WSL 的客户端仓库根目录运行。构建需要 C 编译器、CMake、Ninja、Python 3 和 pkg-config。

```sh
python3 scripts/build-deps.py linux-x86_64
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release \
  -DFASTP2P_DEPS_ROOT="$HOME/fastp2p-dev/cross/prefix/linux-x86_64"
cmake --build build --parallel
ctest --test-dir build --output-on-failure
```

主程序静态链接项目核心与锁定的 TLS/QUIC/HTTP/JSON 依赖，系统 C 库仍由操作系统提供。SDK 包另外包含共享库、头文件、示例、CMake 配置；使用 `find_package(fastp2p CONFIG REQUIRED)` 和 `fastp2p::fastp2p`。

Windows 使用 MinGW，macOS 原生构建，Android 使用 NDK 和 Java/JNI 系统封装。完整依赖许可证已嵌入单文件客户端，运行 `--licenses` 查看。 [平台和发行包](PLATFORMS-ZH.md) · [本地验证与 CI](VALIDATION-ZH.md)

专用构建从仓库根目录的 `common/bootstrap.json` 读取公开的 `host`、`port` 和 `ca`。新安装匹配内置网关和 CA 时，客户端直接从内存加载 CA，配置文件只保存证书指纹。现有的 `CACertFile` 配置和自定义网关证书文件仍可使用。自行部署网关时，可以修改该文件，或通过 CMake 参数 `FASTP2P_BOOTSTRAP_FILE` 选择另一份公开配置。SDK 中的副本名为 `gateway-public.json`。接入 Token 和私钥应存放在私有配置中。

可选的 `tls_alias` 包含 `host` 和 `ca`。客户端匹配内置网关且使用默认信任时，通过这个名称建立并验证 HTTPS/WSS 连接，也会在节点间的 QUIC ClientHello 发送该名称。官方网关的客户端 TLS 名称为 `speedtest.fastp2p.top`，控制台入口为 `fastp2p.top`。

Linux 托管服务的 `config` 目录由 root 持有（0700），`fastp2p.conf` 为 0600，支持网关下发配置时原子替换。旧版服务仅更新二进制时继续使用原有服务账号。重新运行新版安装命令会迁移配置和服务权限。

启动先读取 fastp2p.conf（Linux 内容沿用 JSON；Windows 文件由 DPAPI 加密）。网关控制台不再接受手动字段下发：操作员只需维护转发与 SOCKS5 规则，网关把规则渲染成 `apps`/`socks5` 期望字段并在改动、停用、删除时同步给在线节点（离线节点上线后自动应用）。客户端收到期望字段后按键递归合并（对象逐层合并，数组/标量/null 按整字段替换，未下发的键保留），先验证候选配置，再私密保存、自动重载并重连；端口冲突、启动失败或 25 秒内无法通过网关认证时恢复旧配置。失败版本会被记住，规则改动后重新下发可重试。保留的 .previous 是上次配置备份，_fastp2pManaged 为内部状态，不能远程编辑。

网关同时保存每个节点的期望字段、递增版本号及 queued/saved/applied/failed 确认状态。离线修改会在上线后送达；转发规则界面也同步到配置文件。C 库提供可选的配置回调，由 CLI/宿主处理保存和重载；SDK 默认不写文件。显式命令行连接参数或 FASTP2P_TOKEN 环境覆盖属于调试会话，不宣称支持文件配置重载；系统服务应由安装器生成并从配置文件启动。

安卓从旧网关迁移时，先安装新专用 APK，停止已有客户端进程，再执行 `adb shell am start -n top.fastp2p.cclient/.InstallActivity --es token YOUR_16_DIGIT_TOKEN --ez migrate true`。此标记只允许采用已签名 APK 中内置的目标地址和 CA，不接受 Intent 提供的服务器或证书；新网关验证成功后才替换已加密的配置，保留 DeviceID 和已有规则。普通安装入口仍拒绝跨网关覆盖。

已 Root 的 Android 设备可以在 fastp2p 常驻通知中选择「Root 更新」，点击「申请 Root」，再在 Root 管理器中授权给 fastp2p。开启后，网关发起的更新在校验下载摘要、包名、签名和版本后由系统包管理器安装。静默安装失败时，客户端会发出手动安装通知。再次打开「Root 更新」可以关闭。

### NAT 等级的来源与显示

控制台显示的是两个独立的结论，**不要混读**：

| 列 | 字段 | 判定依据 |
|---|---|---|
| `UDP` | `natLevel` 1–7 | 映射探测 + 公共/自建 STUN 的过滤探测 |
| `TCP` | `tcpNatLevel` 1–4 | 映射探测 + **回调 SYN** 过滤探测 |

`natLevel` 的取值：

| 值 | 含义 |
|---|---|
| 1 / 2 / 3 | 全锥 / 地址受限 / 端口受限（过滤探测有证据时才给）|
| 4 | 对称（映射随目标变化，过滤探测已无意义）|
| 5 | 锥形但过滤无法判定（不猜）|
| 6 | **无 NAT**：STUN 报告的映射与本机地址一致 |
| 7 | 无 NAT 但过滤全丢：对称 UDP 防火墙 |
| 0 | 未测得 |

`tcpNatLevel` 的取值：1 两个回调都通 / 2 只有同地址新端口通 / 3 都不同（端口受限）/ 4 映射对称。STUN 的 `CHANGE-REQUEST` 对 TCP 不存在，所以 TCP 过滤改用真实回调：客户端用**同一本地端口**既拨出（建立映射）又监听，再由探测服务器分别从**同 IP 的另一端口**和**另一个公网 IP** 回连，看哪个能握手。配置项 `network.TCPNatProbe`（如 `"stun.fastp2p.top:3479"`）。探测未完成时该列为空，控制台回退显示映射语义（`映射稳定` / `映射随目标`），不会谎报等级。

UDP 或 TCP 的过滤探测刷新后仍无结论时，客户端会立即清除该协议的旧过滤等级，并在 30 秒后重试。

### 自建 STUN 与 TCP 探测服务器

`scripts/stun/` 下有两个可直接部署的工具：

- `stun-responder.py`：支持 RFC 3489 `CHANGE-REQUEST` 的 UDP STUN。普通请求同 socket 回包；换端口从 `端口+1` 回包；换地址从**另一块本地地址**回包，并在响应里带 RFC 5780 的 `OTHER-ADDRESS`（0x802C）告诉客户端备用地址——有它，配置里只写一个地址就够，换地址探测仍然可信。
- `tcp-probe-server.py`：TCP 回调探测。先告知对端映射地址，再依次从同 IP 新端口、另一公网 IP 发起连接，报告哪个成功。

主机需要两个公网地址，且上游必须同时放行**两个地址的进出**：只把地址配上而出口被过滤时，用该地址作源发包会丢包，换地址应答就不会到达（现象是 STUN 侧 `change-ip` 永远无回包）。UDP 用 `3478`、TCP 用 `3479`，防火墙需同时放行这两种协议。
